# table2csv
Convert any html table to csv

To use current chrome extension in browser recomend to zip current folder and upload from `Chrome Extension Manager`, with `Developer Mode` is on
