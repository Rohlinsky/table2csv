// For background process
